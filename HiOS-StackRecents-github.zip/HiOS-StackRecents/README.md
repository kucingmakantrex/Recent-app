# HiOS Stack Recents

Modul LSPosed/Xposed: recent apps bertumpuk untuk HiOS Launcher 15 (`com.transsion.hilauncher`).

- Kartu kiri menumpuk di belakang kartu tengah.
- Kartu kanan berukuran sama dengan kartu tengah.
- Efek dipasang ulang di setiap frame, jadi tumpukan tidak hilang saat animasi tutup aplikasi.
- Log diagnostik (`DEBUG = true` di `Main.java`) tercatat di LSPosed dengan tag `HiOSStackRecents`
  setiap jumlah kartu berubah. Ubah ke `false` kalau tidak dibutuhkan.

## Build
Push ke GitHub, lalu buka tab **Actions** > **Build APK**. APK ada di *Artifacts*.
Key penandatangan tetap (`keystore/`), jadi update berikutnya bisa langsung menimpa tanpa uninstall.
