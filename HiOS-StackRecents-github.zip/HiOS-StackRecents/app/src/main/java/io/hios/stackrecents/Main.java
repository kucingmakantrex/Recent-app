package io.hios.stackrecents;

import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;

import java.lang.ref.WeakReference;
import java.util.Locale;
import java.util.WeakHashMap;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage.LoadPackageParam;

/**
 * HiOS Stack Recents: recent apps ditumpuk di HiOS Launcher 15.
 *
 * Kartu di kiri (lebih lama) menumpuk di belakang kartu tengah, kartu di kanan
 * ukurannya sama dengan kartu tengah.
 */
public class Main implements IXposedHookLoadPackage {

    private static final String TAG = "[HiOSStackRecents] ";
    private static final String TARGET_PKG = "com.transsion.hilauncher";
    private static final String RECENTS_VIEW = "com.android.quickstep.views.RecentsView";
    private static final String TASK_VIEW = "com.android.quickstep.views.TaskView";

    // ---- parameter efek -------------------------------------------------
    /** Seberapa jauh tumpukan mengintip di kiri (dikali lebar RecentsView). */
    private static final float PEEK = 0.25f;
    /** Kecepatan tumpukan merapat. */
    private static final float PEEK_RATE = 1.3f;
    /** Pengecilan kartu kiri per satu lebar kartu. */
    private static final float SCALE_STEP = 0.04f;
    /** Skala minimum kartu kiri. */
    private static final float MIN_SCALE = 0.85f;
    /** Skala kartu kanan (1.0 = sama dengan kartu tengah). */
    private static final float RIGHT_SCALE = 1.0f;
    /** Jarak antar kartu kanan (dikali lebar RecentsView sudah dibagi step). */
    private static final float RIGHT_STEP = 0.9f;
    /** Kartu kiri mulai memudar setelah sejauh ini (dalam lebar kartu). */
    private static final float FADE_START = 3.0f;
    private static final float FADE_RATE = 0.5f;

    // ---- diagnostik -----------------------------------------------------
    /** Set false kalau log sudah tidak dibutuhkan. */
    private static final boolean DEBUG = true;
    /** Jumlah pemanggilan yang dicatat setelah jumlah kartu berubah. */
    private static final int DEBUG_CALLS = 70;

    private static final int SRC_DRAW = 0;
    private static final int SRC_SCROLL = 1;
    private static final int SRC_LAYOUT = 2;
    private static final int SRC_CURVE = 3;
    private static final int SRC_FRAME = 4;
    private static final String[] SRC_NAME = {"draw", "scroll", "layout", "curve", "frame"};

    private static final WeakHashMap<View, Boolean> TOUCHED = new WeakHashMap<>();
    private static final WeakHashMap<View, FrameHook> FRAME_HOOKS = new WeakHashMap<>();
    private static final WeakHashMap<View, Integer> LAST_COUNT = new WeakHashMap<>();

    private static Class<?> sTaskView;
    private static Class<?> sRecentsView;
    private static boolean sBusy = false;
    private static boolean sDisabled = false;
    private static int sDebugLeft = 0;

    @Override
    public void handleLoadPackage(LoadPackageParam lpparam) {
        if (!TARGET_PKG.equals(lpparam.packageName)) return;

        ClassLoader cl = lpparam.classLoader;
        Class<?> recents = XposedHelpers.findClassIfExists(RECENTS_VIEW, cl);
        sTaskView = XposedHelpers.findClassIfExists(TASK_VIEW, cl);
        sRecentsView = recents;
        if (recents == null || sTaskView == null) {
            XposedBridge.log(TAG + "RecentsView/TaskView tidak ditemukan, modul tidak aktif");
            return;
        }

        try {
            XposedHelpers.findAndHookMethod(recents, "dispatchDraw", android.graphics.Canvas.class,
                    new Hook(SRC_DRAW, true));
        } catch (Throwable t) {
            XposedBridge.log(TAG + "hook dispatchDraw gagal: " + t);
        }
        try {
            XposedHelpers.findAndHookMethod(recents, "onScrollChanged",
                    int.class, int.class, int.class, int.class, new Hook(SRC_SCROLL, false));
        } catch (Throwable t) {
            XposedBridge.log(TAG + "hook onScrollChanged gagal: " + t);
        }
        try {
            XposedHelpers.findAndHookMethod(recents, "onLayout",
                    boolean.class, int.class, int.class, int.class, int.class,
                    new Hook(SRC_LAYOUT, false));
        } catch (Throwable t) {
            XposedBridge.log(TAG + "hook onLayout gagal: " + t);
        }
        try {
            XposedHelpers.findAndHookMethod(recents, "updateCurveProperties",
                    new Hook(SRC_CURVE, false));
        } catch (Throwable t) {
            XposedBridge.log(TAG + "hook updateCurveProperties gagal: " + t);
        }

        XposedBridge.log(TAG + "aktif untuk " + TARGET_PKG);
    }

    // ---------------------------------------------------------------------

    private static final class Hook extends XC_MethodHook {
        private final int src;
        private final boolean before;

        Hook(int src, boolean before) {
            this.src = src;
            this.before = before;
        }

        @Override
        protected void beforeHookedMethod(MethodHookParam param) {
            if (before) guard(param.thisObject, src);
        }

        @Override
        protected void afterHookedMethod(MethodHookParam param) {
            if (!before) guard(param.thisObject, src);
        }
    }

    /**
     * Dipanggil sebelum setiap frame digambar. Launcher menjalankan animasi
     * (misalnya saat kartu ditutup) tanpa memanggil hook di atas, jadi efek
     * tumpukan dipasang ulang di sini supaya tidak hilang sementara.
     */
    private static final class FrameHook
            implements ViewTreeObserver.OnPreDrawListener, View.OnAttachStateChangeListener {
        private final WeakReference<ViewGroup> ref;
        private ViewTreeObserver observer;

        FrameHook(ViewGroup view) {
            ref = new WeakReference<>(view);
        }

        void start(ViewGroup view) {
            stop();
            observer = view.getViewTreeObserver();
            if (observer.isAlive()) observer.addOnPreDrawListener(this);
        }

        void stop() {
            if (observer != null) {
                if (observer.isAlive()) observer.removeOnPreDrawListener(this);
                observer = null;
            }
        }

        @Override
        public boolean onPreDraw() {
            ViewGroup view = ref.get();
            if (view == null) {
                stop();
            } else {
                guard(view, SRC_FRAME);
            }
            return true;
        }

        @Override
        public void onViewAttachedToWindow(View v) {
            if (v instanceof ViewGroup) start((ViewGroup) v);
        }

        @Override
        public void onViewDetachedFromWindow(View v) {
            stop();
        }
    }

    private static void ensureFrameHook(ViewGroup rv) {
        if (FRAME_HOOKS.containsKey(rv)) return;
        FrameHook hook = new FrameHook(rv);
        FRAME_HOOKS.put(rv, hook);
        rv.addOnAttachStateChangeListener(hook);
        if (rv.isAttachedToWindow()) hook.start(rv);
    }

    // ---------------------------------------------------------------------

    private static void guard(Object o, int src) {
        if (sDisabled) return;
        try {
            applyStack(o, src);
        } catch (Throwable t) {
            sDisabled = true;
            XposedBridge.log(TAG + "error, efek dimatikan: " + t);
            XposedBridge.log(t);
        }
    }

    private static boolean isTask(View v) {
        return v != null && sTaskView != null && sTaskView.isInstance(v);
    }

    private static void applyStack(Object o, int src) {
        if (sBusy || !(o instanceof ViewGroup)) return;
        if (sRecentsView != null && !sRecentsView.isInstance(o)) return;

        ViewGroup rv = (ViewGroup) o;
        int w = rv.getWidth();
        int h = rv.getHeight();
        int count = rv.getChildCount();

        // Hanya mode potret; selain itu kembalikan tampilan asli.
        if (w <= 0 || h <= w) {
            for (int i = 0; i < count; i++) reset(rv.getChildAt(i));
            return;
        }

        ensureFrameHook(rv);

        Integer last = LAST_COUNT.get(rv);
        if (last == null || last != count) {
            LAST_COUNT.put(rv, count);
            if (DEBUG && last != null) {
                sDebugLeft = DEBUG_CALLS;
                XposedBridge.log(TAG + "dbg jumlah anak " + last + " -> " + count);
            }
        }
        StringBuilder dbg = null;
        if (DEBUG && sDebugLeft > 0) {
            sDebugLeft--;
            dbg = new StringBuilder(TAG + "dbg src=" + SRC_NAME[src]
                    + " scrollX=" + rv.getScrollX() + " w=" + w);
        }

        sBusy = true;
        try {
            float centerX = rv.getScrollX() + w / 2f;

            // jarak antar kartu (selisih left terkecil yang positif)
            float step = 0f;
            View prev = null;
            for (int i = 0; i < count; i++) {
                View c = rv.getChildAt(i);
                if (!isTask(c)) continue;
                if (prev != null) {
                    int dl = Math.abs(c.getLeft() - prev.getLeft());
                    if (dl > 0 && (step == 0f || dl < step)) step = dl;
                }
                prev = c;
            }
            if (dbg != null) dbg.append(" step=").append((int) step);

            int shownCards = 0;
            for (int i = 0; i < count; i++) {
                View c = rv.getChildAt(i);
                if (!isTask(c)) continue;
                int cw = c.getWidth();
                if (cw <= 0) continue;

                float d = c.getLeft() + cw / 2f - centerX; // <0 kiri, >0 kanan
                float n = Math.abs(d) / cw;

                float preTx = c.getTranslationX();
                float preScale = c.getScaleX();
                float preAlpha = c.getAlpha();

                if (n < 0.02f) {
                    reset(c);
                    if (dbg != null && shownCards++ < 8) {
                        dbg.append(String.format(Locale.US,
                                " [#%d L=%d n=%.2f pre(tx=%.0f s=%.2f a=%.2f) RESET]",
                                i, c.getLeft(), n, preTx, preScale, preAlpha));
                    }
                    continue;
                }

                float tx;
                float scale;
                float alpha;
                if (d > 0f) {
                    // kanan: ukuran sama dengan kartu tengah
                    float st = step > 0f ? step : cw * 1.1f;
                    tx = (cw * RIGHT_STEP / st - 1f) * d;
                    scale = RIGHT_SCALE;
                    alpha = 1f;
                } else {
                    // kiri: menumpuk di belakang kartu tengah
                    float shown = (float) (PEEK * w * (1.0 - Math.exp(-PEEK_RATE * n)));
                    tx = -shown - d;
                    scale = Math.max(MIN_SCALE, 1f - SCALE_STEP * n);
                    alpha = n <= FADE_START ? 1f
                            : Math.max(0f, 1f - (n - FADE_START) * FADE_RATE);
                }

                c.setTranslationX(tx);
                c.setScaleX(scale);
                c.setScaleY(scale);
                c.setAlpha(alpha);
                c.setTranslationZ(d / cw * 10f);
                TOUCHED.put(c, Boolean.TRUE);

                if (dbg != null && shownCards++ < 8) {
                    dbg.append(String.format(Locale.US,
                            " [#%d L=%d n=%.2f%s pre(tx=%.0f s=%.2f a=%.2f) -> tx=%.0f s=%.2f a=%.2f]",
                            i, c.getLeft(), n, d > 0 ? "R" : "L",
                            preTx, preScale, preAlpha, tx, scale, alpha));
                }
            }
        } finally {
            sBusy = false;
        }
        if (dbg != null) XposedBridge.log(dbg.toString());
    }

    private static void reset(View v) {
        if (v == null) return;
        if (TOUCHED.remove(v) == null) return;
        v.setTranslationX(0f);
        v.setScaleX(1f);
        v.setScaleY(1f);
        v.setAlpha(1f);
        v.setTranslationZ(0f);
    }
}
