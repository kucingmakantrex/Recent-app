plugins {
    id("com.android.application")
}

android {
    namespace = "io.hios.stackrecents"
    compileSdk = 34

    defaultConfig {
        applicationId = "io.hios.stackrecents"
        minSdk = 28
        targetSdk = 34
        versionCode = 2
        versionName = "1.1"
    }

    signingConfigs {
        create("release") {
            storeFile = rootProject.file("keystore/hios-stackrecents.jks")
            storePassword = "hiosstack"
            keyAlias = "hios"
            keyPassword = "hiosstack"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("release")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    compileOnly("de.robv.android.xposed:api:82")
}
